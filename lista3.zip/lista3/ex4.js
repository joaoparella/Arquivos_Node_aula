var n=10;
while (n >= 0){
    console.log(n)
    n--;
}

for (var i = 10; i >= 0; i--){
    console.log(i)
}

console.log("Fogo!");